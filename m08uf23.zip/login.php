<?php
require 'vendor/autoload.php';
use Laminas\Ldap\Ldap;

session_start();

if (!isset($_COOKIE["auth"])) {
    setcookie("auth", "true", time()+3600, "/");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $adminDn = 'cn=admin,dc=fjeclot,dc=net';
    $adminPassword = $_POST['adminpass'];
    $usuario = $_POST['usuario'];
    
    $opciones = [
        'host'                   => 'zend-stmeri',
        'username'               => $adminDn,
        'password'               => $adminPassword,
        'bindRequiresDn'         => true,
        'accountDomainName'      => 'fjeclot.net',
        'baseDn'                 => 'dc=fjeclot,dc=net',
    ];
    
    $ldap = new Ldap($opciones);
    
    if ($ldap->bind($usuario, $adminPassword)) {
        $_SESSION['usuari_autenticat'] = true;
        setcookie("auth", "true", time()+3600, "/");
        header("Location: index.php");
        exit();
    } else {
        $error_message = "Usuario o contraseña incorrectos.";
    }
}
?>

<head>
    <title>Iniciar sesión</title>
</head>
<body>
    <form action="login.php" method="post">
        <label for="usuario">Usuario:</label><br>
        <input type="text" id="usuario" name="usuario"><br>
        <label for="adminpass">Contraseña del administrador:</label><br>
        <input type="password" id="adminpass" name="adminpass"><br>
        <input type="submit" value="Iniciar sesión">
    </form>
    <?php if (isset($error_message)) { echo "<p>$error_message</p>"; } ?>
</body>
</html>
