<?php
session_start();

if (!isset($_SESSION['usuari_autenticat']) || $_SESSION['usuari_autenticat'] !== true) {
    header("Location: login.php");
    exit();
}

$uid = '';
$ou = '';
$resultado = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uid = $_POST['uid'];
    $ou = $_POST['ou'];
    
    if (empty($uid) || empty($ou)) {
        $resultado = "Por favor, complete todos los campos.";
    } else {
        $resultado = "Visualizando datos del usuario: UID=$uid, OU=$ou";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar usuario</title>
</head>
<body>
    <h1>Visualizar usuario</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="uid">Identificador del usuario:</label><br>
        <input type="text" id="uid" name="uid" value="<?php echo $uid; ?>"><br><br>
        <label for="ou">Unidad organizativa:</label><br>
        <input type="text" id="ou" name="ou" value="<?php echo $ou; ?>"><br><br>
        <input type="submit" value="Visualizar">
    </form>
    <?php echo $resultado; ?>
    <br>
    <a href="index.php">Volver al panel de control</a>
</body>
</html>
