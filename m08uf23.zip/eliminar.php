<?php
require 'vendor/autoload.php';
use Laminas\Ldap\Ldap;


if ($_COOKIE["auth"] != "true") {
    header("Location: login.php");
    exit();
}

if (isset($_GET['logout'])) {
    setcookie("auth", "false", time()-3600, "/");
    header("Location: login.php");
    exit();
}

ini_set('display_errors', 0);

$uid = $_GET['uid'];
$unorg = $_GET['ou'];

$dn = 'uid=' . $uid . ',ou=' . $unorg . ',dc=fjeclot,dc=net';

$opciones = [
    'host' => 'zend-stmeri.fjeclot.net',
    'username' => 'cn=admin,dc=fjeclot,dc=net',
    'password' => 'fjeclot',
    'bindRequiresDn' => true,
    'accountDomainName' => 'fjeclot.net',
    'baseDn' => 'dc=fjeclot,dc=net',        
];

# Conexión al servidor LDAP
$ldap = new Ldap($opciones);
$ldap->bind();

try {
    // Intentar eliminar la entrada
    $ldap->delete($dn);
    echo "<b>Entrada eliminada</b><br>"; 
} catch (Exception $e) {
    echo "<b>Esta entrada no existe</b><br>";
}

class Ldap
{
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Eliminar usuario</title>
</head>
<body>
    <h1>Eliminar usuario</h1>
    <!-- Links a otras páginas -->
    <ul>
        <li><a href="visualizar.php">Visualización de datos de usuario</a></li>
        <li><a href="agregar.php">Agregar usuario</a></li>
        <li><a href="modificar.php">Modificar atributos de usuario</a></li>
    </ul>
    <!-- Botón de logout -->
    <a href="?logout=true">Logout</a>
</body>
</html>
