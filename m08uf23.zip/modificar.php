<?php
require 'vendor/autoload.php';
use Laminas\Ldap\Attribute;
use Laminas\Ldap\Ldap;

if ($_COOKIE["auth"] != "true") {
    header("Location: login.php");
    exit();
}

if (isset($_GET['logout'])) {
    setcookie("auth", "false", time()-3600, "/");
    header("Location: login.php");
    exit();
}

ini_set('display_errors', 0);

$uid = $_GET['uid'];
$unorg = $_GET['ou'];

$opciones = [
    'host' => 'zend-stmeri.fjeclot.net',
    'username' => 'cn=admin,dc=fjeclot,dc=net',
    'password' => 'fjeclot',
    'bindRequiresDn' => true,
    'accountDomainName' => 'fjeclot.net',
    'baseDn' => 'dc=fjeclot,dc=net',        
];

$ldap = new Ldap($opciones);
$ldap->bind();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $atributo = $_POST['atributo'];
    $nuevo_contenido = $_POST['nuevo_contenido'];

    $dn = 'uid=' . $uid . ',ou=' . $unorg . ',dc=fjeclot,dc=net';

    $entrada = $ldap->getEntry($dn);

    if ($entrada) {
        $atributos_modificables = ['uidNumber', 'gidNumber', 'homeDirectory', 'loginShell', 'cn', 'sn', 'givenName', 'postalAddress', 'mobile', 'telephoneNumber', 'title', 'description'];
        if (in_array($atributo, $atributos_modificables)) {
            Attribute::setAttribute($entrada, $atributo, $nuevo_contenido);
            $ldap->update($dn, $entrada);
            echo "Atributo modificado";
        } else {
            echo "El atributo seleccionado no es modificable";
        }
    } else {
        echo "<b>Aquesta entrada no existeix</b><br><br>";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Modificar atributo de usuario</title>
</head>
<body>
    <h1>Modificar atributo de usuario</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <input type="hidden" name="uid" value="<?php echo $uid; ?>">
        <input type="hidden" name="ou" value="<?php echo $unorg; ?>">
        
        <label for="atributo">Atributo a modificar:</label><br>
        <input type="radio" id="uidNumber" name="atributo" value="uidNumber">
        <label for="uidNumber">Número de identificador de usuario</label><br>
        <input type="radio" id="gidNumber" name="atributo" value="gidNumber">
        <label for="gidNumber">Número de identificador de grupo</label><br>
        <input type="radio" id="homeDirectory" name="atributo" value="homeDirectory">
        <label for="homeDirectory">Directorio de inicio</label><br>
        
        <br>Nuevo contenido: <input type="text" name="nuevo_contenido"><br><br>
        <input type="submit" value="Modificar">
    </form>
    <ul>
        <li><a href="visualizar.php">Visualización de datos de usuario</a></li>
        <li><a href="agregar.php">Agregar usuario</a></li>
        <li><a href="eliminar.php">Eliminar usuario</a></li>
    </ul>
    <a href="?logout=true">Logout</a>
</body>
</html>
