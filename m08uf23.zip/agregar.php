<?php
require 'vendor/autoload.php';
use Laminas\Ldap\Attribute;
use Laminas\Ldap\Ldap;

if ($_COOKIE["auth"] != "true") {
    header("Location: login.php");
    exit();
}

if (isset($_GET['logout'])) {
    setcookie("auth", "false", time()-3600, "/");
    header("Location: login.php");
    exit();
}

ini_set('display_errors', 0);

$uid = $_POST['uid'] ?? '';
$unorg = $_POST['unorg'] ?? '';
$num_id = $_POST['uidNumber'] ?? '';
$grup = $_POST['gidNumber'] ?? '';
$dir_pers = $_POST['homeDirectory'] ?? '';
$sh = $_POST['loginShell'] ?? '';
$cn = $_POST['cn'] ?? '';
$sn = $_POST['sn'] ?? '';
$nom = $_POST['givenName'] ?? '';
$mobil = $_POST['mobile'] ?? '';
$adressa = $_POST['postalAddress'] ?? '';
$telefon = $_POST['telephoneNumber'] ?? '';
$titol = $_POST['title'] ?? '';
$descripcio = $_POST['description'] ?? '';
$objcl = array('inetOrgPerson', 'organizationalPerson', 'person', 'posixAccount', 'shadowAccount', 'top');

$domini = 'dc=fjeclot,dc=net';
$opcions = [
    'host' => 'zend-stmeri.fjeclot.net',
    'username' => "cn=admin,$domini",
    'password' => 'fjeclot',
    'bindRequiresDn' => true,
    'accountDomainName' => 'fjeclot.net',
    'baseDn' => 'dc=fjeclot,dc=net',
];

$ldap = new Ldap($opcions);
$ldap->bind();
$nova_entrada = [];
Attribute::setAttribute($nova_entrada, 'objectClass', $objcl);
Attribute::setAttribute($nova_entrada, 'uid', $uid);
Attribute::setAttribute($nova_entrada, 'uidNumber', $num_id);
Attribute::setAttribute($nova_entrada, 'gidNumber', $grup);
Attribute::setAttribute($nova_entrada, 'homeDirectory', $dir_pers);
Attribute::setAttribute($nova_entrada, 'loginShell', $sh);
Attribute::setAttribute($nova_entrada, 'cn', $cn);
Attribute::setAttribute($nova_entrada, 'sn', $sn);
Attribute::setAttribute($nova_entrada, 'givenName', $nom);
Attribute::setAttribute($nova_entrada, 'mobile', $mobil);
Attribute::setAttribute($nova_entrada, 'postalAddress', $adressa);
Attribute::setAttribute($nova_entrada, 'telephoneNumber', $telefon);
Attribute::setAttribute($nova_entrada, 'title', $titol);
Attribute::setAttribute($nova_entrada, 'description', $descripcio);
$dn = 'uid=' . $uid . ',ou=' . $unorg . ',dc=fjeclot,dc=net';
if ($ldap->add($dn, $nova_entrada)) {
    echo "Usuari creat";
}


?>

<!DOCTYPE html>
<html>
<head>
    <title>Agregar usuario</title>
</head>
<body>
    <h1>Agregar usuario</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        uid: <input type="text" name="uid"><br>
        unitat organitzativa: <input type="text" name="unorg"><br>
        uidNumber: <input type="text" name="uidNumber"><br>
        gidNumber: <input type="text" name="gidNumber"><br>
        Directori personal: <input type="text" name="homeDirectory"><br>
        Shell: <input type="text" name="loginShell"><br>
        cn: <input type="text" name="cn"><br>
        sn: <input type="text" name="sn"><br>
        givenName: <input type="text" name="givenName"><br>
        PostalAdress: <input type="text" name="postalAddress"><br>
        mobile: <input type="text" name="mobile"><br>
        telephoneNumber: <input type="text" name="telephoneNumber"><br>
        title: <input type="text" name="title"><br>
        description: <input type="text" name="description"><br>
        <input type="submit" value="Agregar">
    </form>
    <ul>
        <li><a href="visualizar.php">Visualización de datos de usuario</a></li>
        <li><a href="eliminar.php">Eliminar usuario</a></li>
        <li><a href="modificar.php">Modificar atributos de usuario</a></li>
    </ul>
    <a href="?logout=true">Logout</a>
</body>
</html>
