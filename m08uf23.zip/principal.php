<?php
session_start();

if (!isset($_SESSION['usuari_autenticat']) || $_SESSION['usuari_autenticat'] !== true) {
    header("Location: login.php");
    exit();
}
?>


<html>
<head>
    <title>Página de inicio</title>
</head>
<body>
    <h1>Bienvenido a la página de inicio</h1>
    <ul>
        <li><a href="visualizar.php">Visualización de datos de usuario</a></li>
        <li><a href="agregar.php">Agregar usuario</a></li>
        <li><a href="eliminar.php">Eliminar usuario</a></li>
        <li><a href="modificar.php">Modificar atributos de usuario</a></li>
    </ul>
    <a href="?logout=true">Logout</a>
</body>
</html>
